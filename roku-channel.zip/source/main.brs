Sub Main()
    screen = CreateObject("roVideoScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    video = CreateObject("roAssociativeArray")
    video.StreamUrls = ["http://192.168.0.137:8080/hls/stream.m3u8"]
    video.StreamBitrates = [2000]
    video.StreamQualities = ["HD"]
    video.StreamFormat = "hls"
    video.Title = "Solar Monitor"
    screen.SetContent(video)
    screen.Show()
    while true
        msg = wait(0, port)
        if msg.isScreenClosed() then return
    end while
End Sub
